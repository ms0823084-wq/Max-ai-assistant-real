package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MaxApplication
import com.example.ui.theme.BrightCoral
import com.example.ui.theme.CyberNavy
import com.example.ui.theme.DarkSapphire
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GoldenAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SlateCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val app = context.applicationContext as MaxApplication
    val scope = rememberCoroutineScope()

    var assistantName by remember { mutableStateOf(app.securityManager.assistantName) }
    var wakeWord by remember { mutableStateOf(app.securityManager.wakeWord) }
    var bossName by remember { mutableStateOf(app.securityManager.userCallName) }
    var voiceGender by remember { mutableStateOf(app.securityManager.voiceGender) }
    var voiceSpeed by remember { mutableFloatStateOf(app.securityManager.voiceSpeed) }
    var voicePitch by remember { mutableFloatStateOf(app.securityManager.voicePitch) }

    var geminiKey by remember { mutableStateOf(app.securityManager.geminiApiKey) }
    var isTestingConnection by remember { mutableStateOf(false) }
    var testResultText by remember { mutableStateOf<String?>(null) }
    var isTestSuccessful by remember { mutableStateOf(false) }
    var geminiEnabled by remember { mutableStateOf(app.securityManager.isGeminiEnabled) }
    var voiceUnlockEnabled by remember { mutableStateOf(app.securityManager.isVoiceUnlockEnabled) }
    var unlockPin by remember { mutableStateOf(app.securityManager.unlockPin) }
    var photoLabel by remember { mutableStateOf("QR") }
    var savedPhotos by remember { mutableStateOf(com.example.data.local.QuickPhotos.list(context)) }
    var photoMessage by remember { mutableStateOf("") }
    val photoPicker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri: android.net.Uri? ->
        if (uri != null) {
            val ok = com.example.data.local.QuickPhotos.save(context, photoLabel, uri)
            savedPhotos = com.example.data.local.QuickPhotos.list(context)
            photoMessage = if (ok) "Photo save ho gayi." else "Photo save nahi ho payi."
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberNavy)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = NeonCyan, modifier = Modifier.size(26.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text("ASSISTANT SETTINGS", fontWeight = FontWeight.ExtraBold, color = TextPrimary, fontSize = 16.sp)
        }

        // Assistant Persona & Wake Phrase Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Person, contentDescription = "Persona", tint = GoldenAmber)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Persona & Wake Phrase", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                OutlinedTextField(
                    value = assistantName,
                    onValueChange = {
                        assistantName = it
                        app.securityManager.assistantName = it
                    },
                    label = { Text("Assistant Name (e.g. Max, Zia)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = wakeWord,
                    onValueChange = {
                        wakeWord = it
                        app.securityManager.wakeWord = it
                    },
                    label = { Text("Wake Word Phrase (e.g. 'Bolo Max', 'Hey Zia')") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = bossName,
                    onValueChange = {
                        bossName = it
                        app.securityManager.userCallName = it
                    },
                    label = { Text("What Max calls you (default: 'Boss')") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Voice & Speech Card (Gender, Speed, Pitch)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.RecordVoiceOver, contentDescription = "Voice", tint = ElectricBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Voice & Speech Synthesis", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                Text("Voice Gender", color = TextSecondary, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    val genders = listOf("Female", "Male")
                    for (g in genders) {
                        val isSelected = voiceGender.equals(g, ignoreCase = true)
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) NeonCyan else DeepSlate,
                            modifier = Modifier.clickable {
                                voiceGender = g
                                app.securityManager.voiceGender = g
                                app.ttsManager.applySettings(g, voiceSpeed, voicePitch)
                            }
                        ) {
                            Text(
                                text = g,
                                color = if (isSelected) CyberNavy else TextPrimary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                            )
                        }
                    }
                }

                // Speech Speed Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Speech Speed", color = TextSecondary, fontSize = 12.sp)
                        Text("${"%.2f".format(voiceSpeed)}x", color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = voiceSpeed,
                        onValueChange = {
                            voiceSpeed = it
                            app.securityManager.voiceSpeed = it
                            app.ttsManager.applySettings(voiceGender, it, voicePitch)
                        },
                        valueRange = 0.6f..1.6f,
                        colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = DarkSapphire)
                    )
                }

                // Speech Pitch Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Speech Pitch", color = TextSecondary, fontSize = 12.sp)
                        Text("${"%.2f".format(voicePitch)}x", color = GoldenAmber, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = voicePitch,
                        onValueChange = {
                            voicePitch = it
                            app.securityManager.voicePitch = it
                            app.ttsManager.applySettings(voiceGender, voiceSpeed, it)
                        },
                        valueRange = 0.6f..1.5f,
                        colors = SliderDefaults.colors(thumbColor = GoldenAmber, activeTrackColor = DarkSapphire)
                    )
                }

                Button(
                    onClick = {
                        app.ttsManager.speak("Namaste $bossName! Main hoon $assistantName. Aapki phone screen aur saare controls mere paas hain.")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSapphire),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.VolumeUp, contentDescription = "Test Voice", tint = NeonCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Test Voice Audio", color = NeonCyan)
                }
            }
        }

        // Gemini AI API Key (Stored Encrypted via Android Keystore)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NeonCyan.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Key, contentDescription = "Key", tint = GoldenAmber)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Gemini Live API Key", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                Text(
                    text = "Encrypted in Android Keystore with AES-256 GCM. Never hardcoded. Offline phone commands continue to work without an API key.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )

                OutlinedTextField(
                    value = geminiKey,
                    onValueChange = {
                        geminiKey = it
                        app.securityManager.geminiApiKey = it
                    },
                    label = { Text("Gemini API Key (AIzaSy...)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("gemini_key_input")
                )

                Button(
                    onClick = {
                        isTestingConnection = true
                        testResultText = null
                        scope.launch {
                            val res = app.geminiService.testConnection(geminiKey)
                            isTestingConnection = false
                            res.onSuccess {
                                isTestSuccessful = true
                                testResultText = it
                                app.ttsManager.speak("Gemini API connection successful!")
                            }.onFailure {
                                isTestSuccessful = false
                                testResultText = it.localizedMessage ?: it.message
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("test_connection_button")
                ) {
                    if (isTestingConnection) {
                        CircularProgressIndicator(color = CyberNavy, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Testing...", color = CyberNavy, fontWeight = FontWeight.Bold)
                    } else {
                        Text("Test Connection", color = CyberNavy, fontWeight = FontWeight.Bold)
                    }
                }

                testResultText?.let { msg ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isTestSuccessful) EmeraldGreen.copy(alpha = 0.2f) else BrightCoral.copy(alpha = 0.2f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                if (isTestSuccessful) Icons.Default.CheckCircle else Icons.Default.Error,
                                contentDescription = "Status",
                                tint = if (isTestSuccessful) EmeraldGreen else BrightCoral,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = msg,
                                color = if (isTestSuccessful) EmeraldGreen else BrightCoral,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Gemini switch and voice unlock
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Gemini AI", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "Off ho ya API key na ho to bhi phone commands chalenge. Gemini sirf baatchit ke liye hai.",
                            color = TextSecondary, fontSize = 11.sp, lineHeight = 16.sp
                        )
                    }
                    androidx.compose.material3.Switch(
                        checked = geminiEnabled,
                        onCheckedChange = {
                            geminiEnabled = it
                            app.securityManager.isGeminiEnabled = it
                        }
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Voice Unlock", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "\"Max, mobile unlock karo\" bolne par phone unlock hoga. Sirf PIN lock par kaam karta hai.",
                            color = TextSecondary, fontSize = 11.sp, lineHeight = 16.sp
                        )
                    }
                    androidx.compose.material3.Switch(
                        checked = voiceUnlockEnabled,
                        onCheckedChange = {
                            voiceUnlockEnabled = it
                            app.securityManager.isVoiceUnlockEnabled = it
                        }
                    )
                }

                if (voiceUnlockEnabled) {
                    OutlinedTextField(
                        value = unlockPin,
                        onValueChange = {
                            val clean = it.filter { c -> c.isDigit() }.take(12)
                            unlockPin = clean
                            app.securityManager.unlockPin = clean
                        },
                        label = { Text("Phone lock PIN") },
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = NeonCyan
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        "PIN encrypted rehta hai. Dhyan rahe: jise bhi \"Max\" aur \"unlock\" bolna aata hai wo phone khol sakta hai.",
                        color = BrightCoral, fontSize = 11.sp, lineHeight = 16.sp
                    )
                }
            }
        }

        // Quick Photos (QR etc.)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Quick Photos (QR etc.)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                    "Gallery se photo ek baar yahan save karo. Phir bolo: \"Max, QR nikalo\". Photo full screen aur full brightness mein khulegi. Band karne ke liye photo par tap karo.",
                    color = TextSecondary, fontSize = 11.sp, lineHeight = 16.sp
                )
                OutlinedTextField(
                    value = photoLabel,
                    onValueChange = { photoLabel = it.take(20) },
                    label = { Text("Photo ka naam (jaise QR)") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                androidx.compose.material3.Button(onClick = { photoPicker.launch("image/*") }) {
                    Text("Gallery se photo chuno")
                }
                if (photoMessage.isNotEmpty()) {
                    Text(photoMessage, color = TextSecondary, fontSize = 11.sp)
                }
                savedPhotos.forEach { name ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "$name  -  bolo: Max, ${name.replace("_", " ")} nikalo",
                            color = TextPrimary, fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        )
                        androidx.compose.material3.TextButton(onClick = {
                            com.example.data.local.QuickPhotos.delete(context, name)
                            savedPhotos = com.example.data.local.QuickPhotos.list(context)
                        }) {
                            Text("Delete", color = BrightCoral)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
