package com.example.service

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.core.content.ContextCompat

/** Quick Settings tile: one tap turns hands-free listening on or off, without opening the app. */
class MaxTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        try {
            val intent = Intent(this, VoiceForegroundService::class.java).apply {
                action = VoiceForegroundService.ACTION_TOGGLE_LISTENING
            }
            ContextCompat.startForegroundService(this, intent)
        } catch (e: Exception) {
            // ignore
        }
        refresh()
    }

    private fun refresh() {
        val tile = qsTile ?: return
        tile.state = if (VoiceForegroundService.isRunning) Tile.STATE_INACTIVE else Tile.STATE_ACTIVE
        tile.label = "Max Hands-free"
        tile.updateTile()
    }
}
