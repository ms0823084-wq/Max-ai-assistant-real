package com.example.service

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.MaxApplication

/** Voice reminders ("kal 5 baje dawai yaad dilana"). Survive reboots (rescheduled from BootReceiver). */
object ReminderManager {
    private fun prefs(c: Context) = c.getSharedPreferences("max_reminders", Context.MODE_PRIVATE)

    private fun items(c: Context): MutableSet<String> =
        (prefs(c).getStringSet("items", emptySet()) ?: emptySet()).toMutableSet()

    fun add(c: Context, at: Long, text: String) {
        val cur = items(c)
        cur.add("$at|${text.replace("|", " ")}")
        prefs(c).edit().putStringSet("items", cur).apply()
        schedule(c, at, text)
    }

    fun remove(c: Context, at: Long) {
        val cur = items(c)
        cur.removeAll { it.startsWith("$at|") }
        prefs(c).edit().putStringSet("items", cur).apply()
    }

    fun rescheduleAll(c: Context) {
        val now = System.currentTimeMillis()
        for (item in items(c)) {
            val at = item.substringBefore("|").toLongOrNull() ?: continue
            val text = item.substringAfter("|")
            if (at > now) schedule(c, at, text) else remove(c, at)
        }
    }

    private fun schedule(c: Context, at: Long, text: String) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(c, ReminderReceiver::class.java).putExtra("text", text).putExtra("at", at)
        val pi = PendingIntent.getBroadcast(
            c, (at % Int.MAX_VALUE).toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val text = intent?.getStringExtra("text") ?: "reminder"
        val at = intent?.getLongExtra("at", 0L) ?: 0L
        ReminderManager.remove(context, at)
        val app = context.applicationContext as MaxApplication
        val boss = app.securityManager.userCallName

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("max_reminders", "Reminders", NotificationManager.IMPORTANCE_HIGH)
        )
        val n = android.app.Notification.Builder(context, "max_reminders")
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Yaad dilana")
            .setContentText(text)
            .setAutoCancel(true)
            .build()
        nm.notify((at % 100000).toInt() + 5000, n)

        app.ttsManager.speak("$boss, yaad dila raha hoon: $text")
    }
}
