package com.example.data.local

import android.content.Context

/** Things the user asked the assistant to remember ("meri chaabi almirah mein hai"). */
object MemoryNotes {
    private fun prefs(c: Context) = c.getSharedPreferences("max_memory", Context.MODE_PRIVATE)

    fun list(c: Context): List<String> =
        (prefs(c).getString("notes", "") ?: "").split("\n").map { it.trim() }.filter { it.isNotBlank() }

    fun add(c: Context, note: String) {
        val cur = list(c).toMutableList()
        cur.add(note.replace("\n", " ").trim())
        while (cur.size > 100) cur.removeAt(0)
        prefs(c).edit().putString("notes", cur.joinToString("\n")).apply()
    }

    fun clear(c: Context) {
        prefs(c).edit().remove("notes").apply()
    }
}
