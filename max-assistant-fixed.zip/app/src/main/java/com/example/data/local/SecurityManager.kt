package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.example.BuildConfig
import com.example.data.model.LicensePlan
import com.example.data.model.LicenseStatus
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class SecurityManager(private val context: Context) {

    private val prefs: SharedPreferences = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "max_assistant_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Fallback for JVM/Robolectric or environments without hardware keystore
        context.getSharedPreferences("max_assistant_fallback_prefs", Context.MODE_PRIVATE)
    }

    private val secretSalt = "MaxAssistantSecureHmacSecretKey2026"

    val deviceId: String
        get() = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            ?: "DEFAULT_DEVICE_ID"

    // Gemini API Key: Settings stored value, or fallback to BuildConfig
    var geminiApiKey: String
        get() {
            val stored = prefs.getString("gemini_api_key", "") ?: ""
            if (stored.isNotBlank()) return stored
            return try {
                if (BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY") BuildConfig.GEMINI_API_KEY else ""
            } catch (e: Throwable) {
                ""
            }
        }
        set(value) {
            prefs.edit().putString("gemini_api_key", value.trim()).apply()
        }

    var wakeWord: String
        get() = prefs.getString("wake_word", "Bolo Max") ?: "Bolo Max"
        set(value) = prefs.edit().putString("wake_word", value.trim()).apply()

    var assistantName: String
        get() = prefs.getString("assistant_name", "Max") ?: "Max"
        set(value) = prefs.edit().putString("assistant_name", value.trim()).apply()

    var userCallName: String
        get() = prefs.getString("user_call_name", "Boss") ?: "Boss"
        set(value) = prefs.edit().putString("user_call_name", value.trim()).apply()

    var voiceGender: String
        get() = prefs.getString("voice_gender", "Female") ?: "Female"
        set(value) = prefs.edit().putString("voice_gender", value).apply()

    var voiceSpeed: Float
        get() = prefs.getFloat("voice_speed", 1.0f)
        set(value) = prefs.edit().putFloat("voice_speed", value).apply()

    var voicePitch: Float
        get() = prefs.getFloat("voice_pitch", 1.0f)
        set(value) = prefs.edit().putFloat("voice_pitch", value).apply()

    var isAntiTheftArmed: Boolean
        get() = prefs.getBoolean("anti_theft_armed", false)
        set(value) = prefs.edit().putBoolean("anti_theft_armed", value).apply()

    var antiTheftPin: String
        get() = prefs.getString("anti_theft_pin", "1234") ?: "1234"
        set(value) = prefs.edit().putString("anti_theft_pin", value.trim()).apply()

    var antiTheftPassphrase: String
        get() = prefs.getString("anti_theft_passphrase", "khul ja sim sim") ?: "khul ja sim sim"
        set(value) = prefs.edit().putString("anti_theft_passphrase", value.trim().lowercase()).apply()

    var emergencyContact: String
        get() = prefs.getString("emergency_contact", "") ?: ""
        set(value) = prefs.edit().putString("emergency_contact", value.trim()).apply()

    var isChargerAlarmEnabled: Boolean
        get() = prefs.getBoolean("alarm_on_charger_unplug", true)
        set(value) = prefs.edit().putBoolean("alarm_on_charger_unplug", value).apply()

    var isMovementAlarmEnabled: Boolean
        get() = prefs.getBoolean("alarm_on_movement", true)
        set(value) = prefs.edit().putBoolean("alarm_on_movement", value).apply()

    var isWrongPinAlarmEnabled: Boolean
        get() = prefs.getBoolean("alarm_on_wrong_pin", true)
        set(value) = prefs.edit().putBoolean("alarm_on_wrong_pin", value).apply()

    var motionSensitivity: Float
        get() = prefs.getFloat("motion_sensitivity", 3.2f)
        set(value) = prefs.edit().putFloat("motion_sensitivity", value).apply()

    var emergencyAlertMethod: String
        get() = prefs.getString("emergency_alert_method", "SMS & WhatsApp") ?: "SMS & WhatsApp"
        set(value) = prefs.edit().putString("emergency_alert_method", value).apply()

    var isWhatsAppAutoReplyEnabled: Boolean
        get() = prefs.getBoolean("wa_auto_reply_enabled", false)
        set(value) = prefs.edit().putBoolean("wa_auto_reply_enabled", value).apply()

    var isAutoSendWithoutApproval: Boolean
        get() = prefs.getBoolean("wa_auto_send", false)
        set(value) = prefs.edit().putBoolean("wa_auto_send", value).apply()

    var autoReplyTone: String
        get() = prefs.getString("wa_reply_tone", "friendly and polite in Hinglish") ?: "friendly and polite in Hinglish"
        set(value) = prefs.edit().putString("wa_reply_tone", value).apply()

    var adminPassphrase: String
        get() = prefs.getString("admin_passphrase", "MAXADMIN2026") ?: "MAXADMIN2026"
        set(value) = prefs.edit().putString("admin_passphrase", value).apply()

    var storedLicenseKey: String
        get() = prefs.getString("stored_license_key", "") ?: ""
        set(value) = prefs.edit().putString("stored_license_key", value.trim()).apply()

    /** True after the user says "Max off"; stays off until "Max on". */
    var isAssistantOff: Boolean
        get() = prefs.getBoolean("assistant_off", false)
        set(value) = prefs.edit().putBoolean("assistant_off", value).apply()

    var isGeminiEnabled: Boolean
        get() = prefs.getBoolean("gemini_enabled", true)
        set(value) = prefs.edit().putBoolean("gemini_enabled", value).apply()

    /** API key only when Gemini is switched on; empty otherwise (phone commands still work). */
    val activeGeminiKey: String
        get() = if (isGeminiEnabled) geminiApiKey else ""

    var isVoiceUnlockEnabled: Boolean
        get() = prefs.getBoolean("voice_unlock_enabled", false)
        set(value) = prefs.edit().putBoolean("voice_unlock_enabled", value).apply()

    var unlockPin: String
        get() = prefs.getString("voice_unlock_pin", "") ?: ""
        set(value) = prefs.edit().putString("voice_unlock_pin", value.filter { it.isDigit() }.take(12)).apply()

    var isListeningActive: Boolean
        get() = prefs.getBoolean("is_listening_active", false)
        set(value) = prefs.edit().putBoolean("is_listening_active", value).apply()

    // -------------------------------------------------------------
    // OFFLINE LICENSE VALIDATION AND GENERATION (HMAC-SHA256)
    // -------------------------------------------------------------
    fun generateLicenseKey(targetDeviceId: String, plan: LicensePlan, validityDays: Int = 365): String {
        val devId = targetDeviceId.ifBlank { deviceId }
        val expiryTime = if (plan == LicensePlan.LIFETIME) 0L else System.currentTimeMillis() + (validityDays.toLong() * 86400000L)
        val payload = "$devId:${plan.name}:$expiryTime"
        val signature = computeHmacSha256(payload, secretSalt).take(12).uppercase()
        return "MAX-${plan.name}-$expiryTime-$signature"
    }

    fun validateLicense(key: String): LicenseStatus {
        val trimmed = key.trim()
        if (trimmed.isBlank()) {
            return LicenseStatus(
                key = "",
                plan = LicensePlan.FREE,
                deviceId = deviceId,
                expiryTimestamp = 0L,
                isValid = true
            )
        }

        val parts = trimmed.split("-")
        if (parts.size != 4 || parts[0] != "MAX") {
            return LicenseStatus(
                key = trimmed,
                plan = LicensePlan.FREE,
                deviceId = deviceId,
                isValid = false,
                errorMessage = "Invalid key format. Expected MAX-PLAN-EXPIRY-SIG"
            )
        }

        val planName = parts[1]
        val expiryStr = parts[2]
        val signature = parts[3]

        val plan = try {
            LicensePlan.valueOf(planName.uppercase())
        } catch (e: Exception) {
            return LicenseStatus(key = trimmed, plan = LicensePlan.FREE, deviceId = deviceId, isValid = false, errorMessage = "Unknown plan '$planName'")
        }

        val expiryTime = expiryStr.toLongOrNull() ?: return LicenseStatus(
            key = trimmed,
            plan = plan,
            deviceId = deviceId,
            isValid = false,
            errorMessage = "Invalid expiry timestamp"
        )

        // Verify HMAC signature
        val expectedPayload = "$deviceId:${plan.name}:$expiryTime"
        val expectedSignature = computeHmacSha256(expectedPayload, secretSalt).take(12).uppercase()

        if (!signature.equals(expectedSignature, ignoreCase = true)) {
            return LicenseStatus(
                key = trimmed,
                plan = plan,
                deviceId = deviceId,
                isValid = false,
                errorMessage = "Signature mismatch. Key is tied to another device."
            )
        }

        // Check expiration
        if (plan != LicensePlan.LIFETIME && expiryTime > 0 && System.currentTimeMillis() > expiryTime) {
            return LicenseStatus(
                key = trimmed,
                plan = plan,
                deviceId = deviceId,
                expiryTimestamp = expiryTime,
                isValid = false,
                errorMessage = "License has expired."
            )
        }

        return LicenseStatus(
            key = trimmed,
            plan = plan,
            deviceId = deviceId,
            expiryTimestamp = expiryTime,
            isValid = true,
            errorMessage = null
        )
    }

    fun getCurrentLicenseStatus(): LicenseStatus {
        val key = storedLicenseKey
        return if (key.isBlank()) {
            LicenseStatus(key = "", plan = LicensePlan.FREE, deviceId = deviceId, isValid = true)
        } else {
            validateLicense(key)
        }
    }

    private fun computeHmacSha256(data: String, key: String): String {
        val sha256Hmac = Mac.getInstance("HmacSHA256")
        val secretKey = SecretKeySpec(key.toByteArray(StandardCharsets.UTF_8), "HmacSHA256")
        sha256Hmac.init(secretKey)
        val hash = sha256Hmac.doFinal(data.toByteArray(StandardCharsets.UTF_8))
        return hash.joinToString("") { "%02x".format(it) }
    }
}
